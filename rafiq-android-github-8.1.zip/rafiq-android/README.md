# رِفيق Android 8.0

هذا المشروع يضع نسخة رِفيق داخل تطبيق Android باستخدام Capacitor، بحيث تفتح واجهة التطبيق من الملفات المضمّنة داخل APK ولا تعتمد على الإنترنت لفتح الواجهة.

## GitHub Actions
ارفع المجلد إلى GitHub ثم شغّل workflow باسم **Build Rafiq APK** من تبويب Actions. سيبني APK debug ويضعه كـArtifact.

## مهم
- الإنترنت مطلوب فقط للوظائف التي تحتاج Firebase/خدمات سحابية والمزامنة.
- أول تشغيل لا يحتاج تنزيل `index.html` من الإنترنت لأنه مضمّن داخل APK.
- لا تضع مفاتيح سرية أو كلمات مرور داخل المستودع.
- قواعد Firebase يجب نشرها على مشروعك، وصلاحيات الفريق الطبي يجب أن تكون مضبوطة على السيرفر.

## 8.0
يتضمن PIN محلي، نسخ احتياطي واسترجاع JSON، Sync Center، تحليل 90 يوم، Doctor Brief، Voice Entry، Emergency Card وPatient ID.


## Rafiq 8.1
- Functional app lock with device-local PIN session gate.
- Date-aware 90-day local analytics summary.
- Sync button calls the app sync hook when available.
- Real QR Patient ID using QRCode.js when online; text ID remains the fallback.
- Print-ready workflow can be extended for the Emergency Card.
