import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.rafiq.patient',
  appName: 'رِفيق',
  webDir: 'www',
  bundledWebRuntime: false,
  android: { allowMixedContent: true }
};
export default config;
